<!DOCTYPE html>
<html class="uk-height-1-1">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>SeyService - Erro</title>
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="css/uikit.min.css" />
        <link rel="stylesheet" href="css/uikit.gradient.min.css" />
        <script src="js/jquery.min.js"></script>
        <script src="js/uikit.min.js"></script>
        
    </head>
    <body class="uk-height-1-1" style="background-color: rgb(220,220,255)">
        <div class="uk-grid uk-height-1-1">
            
            <div class="uk-width-medium-1-3 uk-vertical-align uk-container-center uk-row-first">
                <div class="uk-vertical-align-middle">
                    <h1>SeyService</h1>
                    <h3>Ops! Não conseguimos entender a sua solicitação.</h3>
                </div>
            </div>
        </div>
        
    </body>
</html>