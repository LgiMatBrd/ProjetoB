<?php
/*
 * Arquivo controller da view 'home'
 */

if (!defined('ROOT_DIR')) // Impossibilita o acesso direto ao arquivo
    die;

/*
 * Verifica se o usuário está logado.
 * O acesso a este controller é restrito a usuários logados!
 */
if ($logged !== 'in')
{
    header('Location: /home');
    die;
}
    
// Se não houve sessão segura iniciada, deve-se iniciar
if (!defined('SESSION_START'))
    // Nossa segurança personalizada para iniciar uma sessão php.
    sec_session_start();

define('HOME_CONTROLLER', true);

    const OK = 1;
    const WARNING = 2;
    const ERROR = 3;

$msgs = array();
function AddMsg($s, $txt)
{
    global $msgs;
    $msgs[] = [
        $s,
        $txt
    ];
}

function GetMsg()
{
    global $msgs;
    if (isset($msgs[0]))
    {
        $mymsg = array_shift($msgs);
        $mymsg[0] = ($mymsg[0] === ERROR)? 'danger' : ($mymsg[0] === WARNING)? 'warning' : 'info';
        
        return [
            'status' => $mymsg[0],
            'msg' => $mymsg[1]
        ];
    }
    return false;
}




if (isset($_POST['username'], $_POST['email'], $_POST['p'], $_POST['pnome']))
{
    // Limpa e valida os dados passados em 
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Email inválido
        AddMsg(ERROR, 'O endereço de email digitado não é válido');
    }
 
    $password = filter_input(INPUT_POST, 'p', FILTER_SANITIZE_STRING);
    if (strlen($password) != 128) {
        // A senha com hash deve ter 128 caracteres.
        // Caso contrário, algo muito estranho está acontecendo
        AddMsg(ERROR, 'A senha enviada é inválida.');
    }
    
    $pNome = filter_input(INPUT_POST, 'pnome', FILTER_SANITIZE_STRING);
     
    // O nome de usuário e a validade da senha foram conferidas no lado cliente.
    // Não deve haver problemas nesse passo já que ninguém ganha 
    // violando essas regras.
    //
 
    $prep_stmt = 'SELECT id FROM users WHERE email = ? LIMIT 1';
    $stmt = $mysqli->prepare($prep_stmt);
 
    if ($stmt) {
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
 
        if ($stmt->num_rows == 1) {
            // Um usuário com esse email já esixte
            AddMsg(WARNING, 'Já existe um usuário cadastrado com este email.');
        }
    } else {
        AddMsg(ERROR, 'Erro no banco de dados');
    }
    
    $prep_stmt = 'SELECT id FROM users WHERE username = ? LIMIT 1';
    $stmt = $mysqli->prepare($prep_stmt);
 
    if ($stmt) {
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();
 
        if ($stmt->num_rows == 1) {
            // Um usuário com esse email já esixte
            AddMsg(WARNING, 'Este nome de usuário já se encontra cadastrado.');
        }
    } else {
        AddMsg(ERROR, 'Erro no banco de dados');
    }
 
    if (empty($msgs)) {
        // Crie um salt aleatório
        $random_salt = hash('sha512', uniqid(openssl_random_pseudo_bytes(16), TRUE));
        $atributos = 0;
        // Crie uma senha com salt
        $password = hash('sha512', $password . $random_salt);
        
        $create_time = gmdate('Y-m-d H:i:s');
         
        // Inserir o novo usuário no banco de dados 
        if ($insert_stmt = $mysqli->prepare("INSERT INTO users (username, pass, salt, email, create_time, atributos, pNome) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
            $insert_stmt->bind_param('sssssis', $username, $password, $random_salt, $email, $create_time, $atributos, $pNome);
            // Executar a tarefa pré-estabelecida.
            if (! $insert_stmt->execute()) {
                AddMsg(ERROR, 'Falha ao registrar usuário');
            }
            else
            {
                AddMsg(OK, 'Usuário cadastrado!');
            }
        }
    }
}

// Provê a view do controller
include ROOT_DIR.'/views/home.php';
